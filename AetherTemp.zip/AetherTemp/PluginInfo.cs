﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "zyro.aethertemp";
        public const string Name = "Aether Temp";
        public const string Description = "made by zyro.yz";
        public const string Version = "1.0.0";
    }
}
